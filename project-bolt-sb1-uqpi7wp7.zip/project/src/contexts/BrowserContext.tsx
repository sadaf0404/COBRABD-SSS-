import React, { createContext, useState, useEffect } from 'react';
import { Tab, Bookmark, HistoryItem } from '../types/browser';

interface BrowserContextType {
  tabs: Tab[];
  activeTabId: string;
  addTab: (url?: string) => void;
  closeTab: (id: string) => void;
  setActiveTab: (id: string) => void;
  updateTabUrl: (id: string, url: string) => void;
  updateTabTitle: (id: string, title: string) => void;
  navigateBack: (tabId: string) => void;
  navigateForward: (tabId: string) => void;
  refreshTab: (tabId: string) => void;
  bookmarks: Bookmark[];
  addBookmark: (url: string, title: string) => void;
  removeBookmark: (id: string) => void;
  history: HistoryItem[];
  addHistoryItem: (url: string, title: string) => void;
  clearHistory: () => void;
  isPrivateMode: boolean;
  togglePrivateMode: () => void;
  showSidebar: boolean;
  setShowSidebar: (show: boolean) => void;
  sidebarContent: 'bookmarks' | 'history' | 'downloads' | 'settings';
  setSidebarContent: (content: 'bookmarks' | 'history' | 'downloads' | 'settings') => void;
}

export const BrowserContext = createContext<BrowserContextType>({} as BrowserContextType);

interface BrowserProviderProps {
  children: React.ReactNode;
}

const generateId = () => Math.random().toString(36).substring(2, 9);

const BrowserProvider: React.FC<BrowserProviderProps> = ({ children }) => {
  const [tabs, setTabs] = useState<Tab[]>([]);
  const [activeTabId, setActiveTabId] = useState<string>('');
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isPrivateMode, setIsPrivateMode] = useState(false);
  const [showSidebar, setShowSidebar] = useState(false);
  const [sidebarContent, setSidebarContent] = useState<'bookmarks' | 'history' | 'downloads' | 'settings'>('bookmarks');

  // Initialize with a default tab
  useEffect(() => {
    if (tabs.length === 0) {
      const defaultTab: Tab = {
        id: generateId(),
        url: 'https://www.google.com',
        title: 'New Tab',
        favicon: '',
        history: ['https://www.google.com'],
        historyIndex: 0,
        isLoading: false,
      };
      setTabs([defaultTab]);
      setActiveTabId(defaultTab.id);
    }
  }, [tabs]);

  // Load bookmarks and history from localStorage
  useEffect(() => {
    const savedBookmarks = localStorage.getItem('bookmarks');
    if (savedBookmarks) {
      setBookmarks(JSON.parse(savedBookmarks));
    }

    const savedHistory = localStorage.getItem('history');
    if (savedHistory && !isPrivateMode) {
      setHistory(JSON.parse(savedHistory));
    }
  }, [isPrivateMode]);

  // Save bookmarks and history to localStorage
  useEffect(() => {
    localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
    if (!isPrivateMode) {
      localStorage.setItem('history', JSON.stringify(history));
    }
  }, [bookmarks, history, isPrivateMode]);

  const addTab = (url = 'https://www.google.com') => {
    const newTab: Tab = {
      id: generateId(),
      url,
      title: 'New Tab',
      favicon: '',
      history: [url],
      historyIndex: 0,
      isLoading: false,
    };
    setTabs([...tabs, newTab]);
    setActiveTabId(newTab.id);
  };

  const closeTab = (id: string) => {
    if (tabs.length === 1) {
      // Don't close the last tab, create a new empty one instead
      const newTab: Tab = {
        id: generateId(),
        url: 'https://www.google.com',
        title: 'New Tab',
        favicon: '',
        history: ['https://www.google.com'],
        historyIndex: 0,
        isLoading: false,
      };
      setTabs([newTab]);
      setActiveTabId(newTab.id);
    } else {
      const tabIndex = tabs.findIndex(tab => tab.id === id);
      const newTabs = tabs.filter(tab => tab.id !== id);
      
      if (id === activeTabId) {
        // If we're closing the active tab, activate an adjacent tab
        const newActiveIndex = Math.min(tabIndex, newTabs.length - 1);
        setActiveTabId(newTabs[newActiveIndex].id);
      }
      
      setTabs(newTabs);
    }
  };

  const setActiveTab = (id: string) => {
    setActiveTabId(id);
  };

  const updateTabUrl = (id: string, url: string) => {
    setTabs(prevTabs => {
      return prevTabs.map(tab => {
        if (tab.id === id) {
          // Update history for navigation
          const newHistory = tab.history.slice(0, tab.historyIndex + 1);
          newHistory.push(url);
          
          return {
            ...tab,
            url,
            isLoading: true,
            history: newHistory,
            historyIndex: newHistory.length - 1
          };
        }
        return tab;
      });
    });

    // Add to history (unless in private mode)
    if (!isPrivateMode) {
      addHistoryItem(url, 'Loading...');
    }
  };

  const updateTabTitle = (id: string, title: string) => {
    setTabs(prevTabs => {
      return prevTabs.map(tab => {
        if (tab.id === id) {
          return { ...tab, title, isLoading: false };
        }
        return tab;
      });
    });

    // Update history item title
    if (!isPrivateMode) {
      const tab = tabs.find(tab => tab.id === id);
      if (tab) {
        updateHistoryItemTitle(tab.url, title);
      }
    }
  };

  const navigateBack = (tabId: string) => {
    setTabs(prevTabs => {
      return prevTabs.map(tab => {
        if (tab.id === tabId && tab.historyIndex > 0) {
          const newIndex = tab.historyIndex - 1;
          return {
            ...tab,
            url: tab.history[newIndex],
            historyIndex: newIndex,
            isLoading: true
          };
        }
        return tab;
      });
    });
  };

  const navigateForward = (tabId: string) => {
    setTabs(prevTabs => {
      return prevTabs.map(tab => {
        if (tab.id === tabId && tab.historyIndex < tab.history.length - 1) {
          const newIndex = tab.historyIndex + 1;
          return {
            ...tab,
            url: tab.history[newIndex],
            historyIndex: newIndex,
            isLoading: true
          };
        }
        return tab;
      });
    });
  };

  const refreshTab = (tabId: string) => {
    setTabs(prevTabs => {
      return prevTabs.map(tab => {
        if (tab.id === tabId) {
          return { ...tab, isLoading: true };
        }
        return tab;
      });
    });
  };

  const addBookmark = (url: string, title: string) => {
    const newBookmark: Bookmark = {
      id: generateId(),
      url,
      title,
      createdAt: new Date().toISOString()
    };
    setBookmarks([...bookmarks, newBookmark]);
  };

  const removeBookmark = (id: string) => {
    setBookmarks(bookmarks.filter(bookmark => bookmark.id !== id));
  };

  const addHistoryItem = (url: string, title: string) => {
    if (isPrivateMode) return;

    const timestamp = new Date().toISOString();
    const existingItem = history.find(item => item.url === url);
    
    if (existingItem) {
      setHistory(history.map(item => {
        if (item.url === url) {
          return {
            ...item,
            title: title !== 'Loading...' ? title : item.title,
            visits: item.visits + 1,
            lastVisit: timestamp
          };
        }
        return item;
      }));
    } else {
      const newItem: HistoryItem = {
        id: generateId(),
        url,
        title,
        visits: 1,
        firstVisit: timestamp,
        lastVisit: timestamp
      };
      setHistory([newItem, ...history]);
    }
  };

  const updateHistoryItemTitle = (url: string, title: string) => {
    if (isPrivateMode || title === 'Loading...') return;

    setHistory(history.map(item => {
      if (item.url === url) {
        return { ...item, title };
      }
      return item;
    }));
  };

  const clearHistory = () => {
    setHistory([]);
  };

  const togglePrivateMode = () => {
    setIsPrivateMode(!isPrivateMode);
  };

  return (
    <BrowserContext.Provider 
      value={{
        tabs,
        activeTabId,
        addTab,
        closeTab,
        setActiveTab,
        updateTabUrl,
        updateTabTitle,
        navigateBack,
        navigateForward,
        refreshTab,
        bookmarks,
        addBookmark,
        removeBookmark,
        history,
        addHistoryItem,
        clearHistory,
        isPrivateMode,
        togglePrivateMode,
        showSidebar,
        setShowSidebar,
        sidebarContent,
        setSidebarContent
      }}
    >
      {children}
    </BrowserContext.Provider>
  );
};

export default BrowserProvider;