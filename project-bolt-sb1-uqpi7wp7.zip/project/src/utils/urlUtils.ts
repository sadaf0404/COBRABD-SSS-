export const isValidUrl = (url: string): boolean => {
  try {
    const pattern = /^(https?:\/\/)?([\w-]+\.)+[\w-]+(\/[\w-./?%&=]*)?$/;
    return pattern.test(url);
  } catch (e) {
    return false;
  }
};

export const getDisplayUrl = (url: string): string => {
  try {
    const urlObj = new URL(url);
    const path = urlObj.pathname === '/' ? '' : urlObj.pathname;
    return `${urlObj.hostname}${path}`;
  } catch (e) {
    return url;
  }
};

export const getSearchUrl = (searchTerm: string): string => {
  const encodedSearchTerm = encodeURIComponent(searchTerm);
  return `https://www.google.com/search?q=${encodedSearchTerm}`;
};

export const getDomain = (url: string): string => {
  try {
    return new URL(url).hostname;
  } catch (e) {
    return url;
  }
};

export const getSuggestions = async (query: string): Promise<string[]> => {
  if (!query) return [];
  
  try {
    const response = await fetch(
      `https://suggestqueries.google.com/complete/search?client=chrome&q=${encodeURIComponent(query)}`,
      { mode: 'no-cors' }
    );
    
    // Simulate suggestions since we can't actually access Google's API
    return [
      `${query} news`,
      `${query} weather`,
      `${query} maps`,
      `${query} images`,
      `${query} videos`
    ];
  } catch (error) {
    console.error('Error fetching suggestions:', error);
    return [];
  }
};

export const isInternalUrl = (url: string): boolean => {
  try {
    const urlObj = new URL(url);
    return urlObj.protocol === 'chrome:';
  } catch (e) {
    return false;
  }
};

export const getDefaultNewTabUrl = (): string => {
  return 'chrome://newtab';
};