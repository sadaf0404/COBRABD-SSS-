import React, { useContext, useEffect, useRef } from 'react';
import { BrowserContext } from '../../contexts/BrowserContext';
import { ThemeContext } from '../../contexts/ThemeContext';
import { AlertCircle, Globe } from 'lucide-react';

const BrowserContent: React.FC = () => {
  const { tabs, activeTabId, updateTabTitle } = useContext(BrowserContext);
  const { theme } = useContext(ThemeContext);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  
  const activeTab = tabs.find(tab => tab.id === activeTabId);

  const handleIframeLoad = () => {
    if (!activeTab) return;
    
    try {
      const iframe = iframeRef.current;
      if (iframe && iframe.contentWindow) {
        const title = iframe.contentWindow.document.title || activeTab.url;
        updateTabTitle(activeTab.id, title);
      }
    } catch (error) {
      updateTabTitle(activeTab.id, activeTab.url);
    }
  };

  const renderWebContent = () => {
    if (!activeTab?.url) return null;

    try {
      const url = new URL(activeTab.url);
      
      // Handle special URLs
      if (url.protocol === 'chrome:') {
        return renderChromeContent(url.pathname);
      }

      // Handle regular web content
      return (
        <iframe
          ref={iframeRef}
          src={activeTab.url}
          className="w-full h-full border-0"
          title={activeTab.title}
          onLoad={handleIframeLoad}
          sandbox="allow-same-origin allow-scripts allow-forms"
        />
      );
    } catch (error) {
      return renderErrorPage();
    }
  };

  const renderChromeContent = (path: string) => {
    switch (path) {
      case '//newtab':
        return renderNewTab();
      case '//settings':
        return renderSettings();
      default:
        return renderErrorPage();
    }
  };

  const renderNewTab = () => {
    return (
      <div className={`flex flex-col items-center justify-center h-full ${
        theme === 'dark' ? 'bg-gray-900 text-white' : 'bg-white text-gray-900'
      }`}>
        <Globe size={48} className={`mb-4 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`} />
        <h1 className="text-2xl font-semibold mb-4">New Tab</h1>
        <div className={`max-w-lg text-center ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
          <p>Type a URL in the address bar or search with Google</p>
        </div>
      </div>
    );
  };

  const renderSettings = () => {
    return (
      <div className={`p-8 ${theme === 'dark' ? 'bg-gray-900 text-white' : 'bg-white text-gray-900'}`}>
        <h1 className="text-2xl font-semibold mb-4">Browser Settings</h1>
        <p>Settings page content would go here</p>
      </div>
    );
  };

  const renderErrorPage = () => {
    return (
      <div className={`flex flex-col items-center justify-center h-full ${
        theme === 'dark' ? 'text-white bg-gray-900' : 'text-gray-900 bg-white'
      }`}>
        <AlertCircle size={48} className="text-red-500 mb-4" />
        <h2 className="text-xl font-semibold mb-2">Page Not Available</h2>
        <p className="max-w-md text-center mb-4">
          The page you're trying to access cannot be loaded due to browser security restrictions.
        </p>
        <p className="max-w-md text-center text-sm">
          Try visiting another website or using the search feature.
        </p>
      </div>
    );
  };

  return (
    <div className="flex-1 overflow-hidden relative">
      {activeTab ? (
        renderWebContent()
      ) : (
        <div className={`flex items-center justify-center h-full ${
          theme === 'dark' ? 'bg-gray-900 text-white' : 'bg-white text-gray-900'
        }`}>
          <p>No active tab</p>
        </div>
      )}
    </div>
  );
};

export default BrowserContent;