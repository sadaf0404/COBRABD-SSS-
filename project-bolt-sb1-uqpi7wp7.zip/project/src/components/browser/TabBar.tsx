import React, { useContext } from 'react';
import { BrowserContext } from '../../contexts/BrowserContext';
import { ThemeContext } from '../../contexts/ThemeContext';
import { X, Plus, Loader2 } from 'lucide-react';

const TabBar: React.FC = () => {
  const { tabs, activeTabId, addTab, closeTab, setActiveTab } = useContext(BrowserContext);
  const { theme } = useContext(ThemeContext);

  return (
    <div className={`flex items-center h-10 px-2 overflow-x-auto ${
      theme === 'dark' ? 'bg-gray-800' : 'bg-gray-100'
    }`}>
      {tabs.map(tab => (
        <div
          key={tab.id}
          className={`flex items-center min-w-[180px] max-w-[240px] h-8 px-3 mr-1 rounded-t-md truncate cursor-pointer transition-colors duration-200 ${
            activeTabId === tab.id 
              ? theme === 'dark' 
                ? 'bg-gray-700 text-white' 
                : 'bg-white text-gray-900'
              : theme === 'dark'
                ? 'bg-gray-800 text-gray-300 hover:bg-gray-700' 
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
          onClick={() => setActiveTab(tab.id)}
        >
          {tab.isLoading ? (
            <Loader2 size={16} className="mr-2 animate-spin" />
          ) : (
            tab.favicon && (
              <img src={tab.favicon} alt="" className="w-4 h-4 mr-2" />
            )
          )}
          <span className="flex-1 truncate text-sm">{tab.title || 'New Tab'}</span>
          <button
            className={`ml-2 rounded-full p-1 opacity-0 group-hover:opacity-100 ${
              theme === 'dark' ? 'hover:bg-gray-600' : 'hover:bg-gray-300'
            }`}
            onClick={(e) => {
              e.stopPropagation();
              closeTab(tab.id);
            }}
          >
            <X size={14} />
          </button>
        </div>
      ))}
      
      <button
        className={`flex items-center justify-center w-8 h-8 rounded-md ${
          theme === 'dark' ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-300'
        }`}
        onClick={() => addTab()}
      >
        <Plus size={20} />
      </button>
    </div>
  );
};

export default TabBar;