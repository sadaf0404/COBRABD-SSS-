import React, { useContext, useState, useRef, useEffect } from 'react';
import { BrowserContext } from '../../contexts/BrowserContext';
import { ThemeContext } from '../../contexts/ThemeContext';
import { 
  ChevronLeft, 
  ChevronRight, 
  RotateCw, 
  Home, 
  Bookmark, 
  Shield, 
  Search,
  X,
  Star,
  Lock,
  Globe
} from 'lucide-react';
import { isValidUrl, getDisplayUrl, getSearchUrl, getSuggestions } from '../../utils/urlUtils';

const NavigationBar: React.FC = () => {
  const { 
    tabs, 
    activeTabId, 
    updateTabUrl, 
    navigateBack, 
    navigateForward, 
    refreshTab,
    bookmarks,
    addBookmark,
    isPrivateMode
  } = useContext(BrowserContext);
  const { theme } = useContext(ThemeContext);
  
  const [inputUrl, setInputUrl] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const suggestionsRef = useRef<HTMLDivElement>(null);

  const activeTab = tabs.find(tab => tab.id === activeTabId);
  
  useEffect(() => {
    if (activeTab) {
      setInputUrl(activeTab.url);
    }
  }, [activeTab?.url]);

  useEffect(() => {
    const fetchSuggestions = async () => {
      if (inputUrl && isFocused && !isValidUrl(inputUrl)) {
        const newSuggestions = await getSuggestions(inputUrl);
        setSuggestions(newSuggestions);
        setShowSuggestions(true);
      } else {
        setShowSuggestions(false);
      }
    };

    const timeoutId = setTimeout(fetchSuggestions, 200);
    return () => clearTimeout(timeoutId);
  }, [inputUrl, isFocused]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        suggestionsRef.current &&
        !suggestionsRef.current.contains(event.target as Node) &&
        !inputRef.current?.contains(event.target as Node)
      ) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const canGoBack = activeTab ? activeTab.historyIndex > 0 : false;
  const canGoForward = activeTab ? activeTab.historyIndex < activeTab.history.length - 1 : false;
  
  const handleNavigate = (url?: string) => {
    if (!activeTab) return;
    
    let navigateUrl = (url || inputUrl).trim();
    
    if (navigateUrl) {
      if (!isValidUrl(navigateUrl)) {
        navigateUrl = getSearchUrl(navigateUrl);
      } else if (!navigateUrl.startsWith('http')) {
        navigateUrl = `https://${navigateUrl}`;
      }
      
      updateTabUrl(activeTab.id, navigateUrl);
      setShowSuggestions(false);
    }
  };

  const handleInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleNavigate();
    } else if (e.key === 'Escape') {
      setShowSuggestions(false);
    }
  };

  const isBookmarked = activeTab ? bookmarks.some(b => b.url === activeTab.url) : false;

  const toggleBookmark = () => {
    if (!activeTab) return;
    
    if (isBookmarked) {
      // Handle unbookmark in the future
    } else {
      addBookmark(activeTab.url, activeTab.title);
    }
  };

  return (
    <div className={`flex items-center h-12 px-3 ${
      theme === 'dark' ? 'bg-gray-800' : 'bg-gray-100'
    }`}>
      <div className="flex space-x-1 mr-3">
        <button 
          className={`p-2 rounded-full ${
            canGoBack 
              ? theme === 'dark' 
                ? 'text-white hover:bg-gray-700' 
                : 'text-gray-700 hover:bg-gray-300'
              : theme === 'dark'
                ? 'text-gray-600' 
                : 'text-gray-400'
          }`}
          onClick={() => activeTab && navigateBack(activeTab.id)}
          disabled={!canGoBack}
        >
          <ChevronLeft size={18} />
        </button>
        
        <button 
          className={`p-2 rounded-full ${
            canGoForward 
              ? theme === 'dark' 
                ? 'text-white hover:bg-gray-700' 
                : 'text-gray-700 hover:bg-gray-300'
              : theme === 'dark'
                ? 'text-gray-600' 
                : 'text-gray-400'
          }`}
          onClick={() => activeTab && navigateForward(activeTab.id)}
          disabled={!canGoForward}
        >
          <ChevronRight size={18} />
        </button>
        
        <button 
          className={`p-2 rounded-full ${
            theme === 'dark' ? 'text-white hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-300'
          }`}
          onClick={() => activeTab && refreshTab(activeTab.id)}
        >
          <RotateCw size={18} />
        </button>
        
        <button 
          className={`p-2 rounded-full ${
            theme === 'dark' ? 'text-white hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-300'
          }`}
          onClick={() => activeTab && updateTabUrl(activeTab.id, 'https://www.google.com')}
        >
          <Home size={18} />
        </button>
      </div>
      
      <div className="relative flex-1">
        <div className={`flex items-center ${
          theme === 'dark' ? 'bg-gray-700' : 'bg-white'
        } rounded-lg h-9 ${
          isFocused ? 'ring-2 ring-blue-500' : ''
        }`}>
          {activeTab && activeTab.url.startsWith('https') && (
            <div className={`flex items-center pl-3 ${
              theme === 'dark' ? 'text-green-400' : 'text-green-600'
            }`}>
              <Lock size={16} />
            </div>
          )}
          
          <input
            ref={inputRef}
            type="text"
            value={inputUrl}
            onChange={(e) => setInputUrl(e.target.value)}
            onKeyDown={handleInputKeyDown}
            onFocus={() => {
              setIsFocused(true);
              setShowSuggestions(true);
            }}
            onBlur={() => setIsFocused(false)}
            className={`w-full h-full px-3 bg-transparent focus:outline-none ${
              theme === 'dark' ? 'text-white' : 'text-gray-900'
            }`}
            placeholder="Search Google or enter a URL"
          />
          
          {inputUrl && isFocused && (
            <button 
              className={`p-1 mr-1 rounded-full ${
                theme === 'dark' ? 'text-gray-400 hover:bg-gray-600' : 'text-gray-500 hover:bg-gray-200'
              }`}
              onClick={() => setInputUrl('')}
            >
              <X size={16} />
            </button>
          )}
          
          {!isFocused && !inputUrl && (
            <div className={`absolute left-3 flex items-center ${
              theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
            }`}>
              <Search size={16} className="mr-2" />
              <span>Search Google or enter a URL</span>
            </div>
          )}
        </div>

        {showSuggestions && suggestions.length > 0 && (
          <div
            ref={suggestionsRef}
            className={`absolute w-full mt-1 py-2 rounded-lg shadow-lg ${
              theme === 'dark' ? 'bg-gray-700' : 'bg-white'
            } z-50`}
          >
            {suggestions.map((suggestion, index) => (
              <div
                key={index}
                className={`flex items-center px-4 py-2 cursor-pointer ${
                  theme === 'dark' 
                    ? 'hover:bg-gray-600' 
                    : 'hover:bg-gray-100'
                }`}
                onClick={() => handleNavigate(suggestion)}
              >
                <Search size={16} className="mr-3 text-gray-400" />
                <span>{suggestion}</span>
              </div>
            ))}
          </div>
        )}
      </div>
      
      <div className="flex space-x-1 ml-3">
        <button 
          className={`p-2 rounded-full ${
            theme === 'dark' ? 'text-white hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-300'
          }`}
          onClick={toggleBookmark}
        >
          <Star size={18} className={isBookmarked ? 'fill-yellow-400 text-yellow-400' : ''} />
        </button>
        
        {isPrivateMode && (
          <div className={`p-2 rounded-full ${
            theme === 'dark' ? 'text-purple-400' : 'text-purple-600'
          }`}>
            <Shield size={18} />
          </div>
        )}
      </div>
    </div>
  );
};

export default NavigationBar;