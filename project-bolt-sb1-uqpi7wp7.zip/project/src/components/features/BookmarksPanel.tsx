import React, { useContext } from 'react';
import { BrowserContext } from '../../contexts/BrowserContext';
import { ThemeContext } from '../../contexts/ThemeContext';
import { Globe, Trash2 } from 'lucide-react';

const BookmarksPanel: React.FC = () => {
  const { bookmarks, removeBookmark, updateTabUrl, activeTabId } = useContext(BrowserContext);
  const { theme } = useContext(ThemeContext);

  const handleBookmarkClick = (url: string) => {
    if (activeTabId) {
      updateTabUrl(activeTabId, url);
    }
  };

  return (
    <div className="p-3">
      {bookmarks.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-40 text-center">
          <Globe size={32} className={`mb-2 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`} />
          <p className={theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}>
            No bookmarks yet
          </p>
          <p className={`text-sm mt-1 ${theme === 'dark' ? 'text-gray-500' : 'text-gray-400'}`}>
            Click the star icon in the address bar to add bookmarks
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {bookmarks.map(bookmark => (
            <div
              key={bookmark.id}
              className={`flex items-center p-2 rounded ${
                theme === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-100'
              } group cursor-pointer`}
            >
              <div 
                className="flex-1 overflow-hidden"
                onClick={() => handleBookmarkClick(bookmark.url)}
              >
                <div className="flex items-center">
                  <div className={`w-8 h-8 flex items-center justify-center rounded ${
                    theme === 'dark' ? 'bg-gray-700' : 'bg-gray-200'
                  }`}>
                    <Globe size={16} />
                  </div>
                  <div className="ml-2 overflow-hidden">
                    <div className="truncate font-medium">{bookmark.title}</div>
                    <div className={`text-xs truncate ${
                      theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
                    }`}>
                      {bookmark.url}
                    </div>
                  </div>
                </div>
              </div>
              <button
                className={`p-2 rounded-full opacity-0 group-hover:opacity-100 ${
                  theme === 'dark' ? 'hover:bg-gray-600 text-gray-300' : 'hover:bg-gray-200 text-gray-500'
                }`}
                onClick={() => removeBookmark(bookmark.id)}
              >
                <Trash2 size={16} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default BookmarksPanel;