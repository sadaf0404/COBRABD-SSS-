import React, { useContext } from 'react';
import { BrowserContext } from '../../contexts/BrowserContext';
import { ThemeContext } from '../../contexts/ThemeContext';
import { Clock, Trash2, Globe } from 'lucide-react';
import { formatDistanceToNow } from '../../utils/dateUtils';

const HistoryPanel: React.FC = () => {
  const { history, clearHistory, updateTabUrl, activeTabId, isPrivateMode } = useContext(BrowserContext);
  const { theme } = useContext(ThemeContext);

  const handleHistoryClick = (url: string) => {
    if (activeTabId) {
      updateTabUrl(activeTabId, url);
    }
  };

  // Group history items by date
  const groupedHistory = history.reduce((acc, item) => {
    const date = new Date(item.lastVisit).toLocaleDateString();
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(item);
    return acc;
  }, {} as Record<string, typeof history>);

  return (
    <div className="p-3">
      {isPrivateMode ? (
        <div className="flex flex-col items-center justify-center h-40 text-center">
          <Clock size={32} className={`mb-2 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`} />
          <p className={theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}>
            History is not recorded in private mode
          </p>
        </div>
      ) : history.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-40 text-center">
          <Clock size={32} className={`mb-2 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`} />
          <p className={theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}>
            No browsing history
          </p>
        </div>
      ) : (
        <div>
          <div className="flex justify-end mb-3">
            <button
              className={`px-3 py-1 text-sm rounded ${
                theme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-200 hover:bg-gray-300'
              }`}
              onClick={clearHistory}
            >
              Clear all history
            </button>
          </div>
          
          <div className="space-y-4">
            {Object.entries(groupedHistory).map(([date, items]) => (
              <div key={date}>
                <h3 className={`text-sm font-medium mb-2 ${
                  theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
                }`}>
                  {date === new Date().toLocaleDateString() ? 'Today' : date}
                </h3>
                <div className="space-y-2">
                  {items.map(item => (
                    <div
                      key={item.id}
                      className={`flex items-center p-2 rounded ${
                        theme === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-100'
                      } group cursor-pointer`}
                      onClick={() => handleHistoryClick(item.url)}
                    >
                      <div className={`w-8 h-8 flex items-center justify-center rounded ${
                        theme === 'dark' ? 'bg-gray-700' : 'bg-gray-200'
                      }`}>
                        <Globe size={16} />
                      </div>
                      <div className="ml-2 overflow-hidden flex-1">
                        <div className="truncate font-medium">{item.title}</div>
                        <div className="flex items-center">
                          <div className={`text-xs truncate flex-1 ${
                            theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
                          }`}>
                            {item.url}
                          </div>
                          <div className={`text-xs ${
                            theme === 'dark' ? 'text-gray-500' : 'text-gray-400'
                          }`}>
                            {formatDistanceToNow(new Date(item.lastVisit))}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default HistoryPanel;