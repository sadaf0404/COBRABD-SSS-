import React, { useContext } from 'react';
import { BrowserContext } from '../../contexts/BrowserContext';
import { ThemeContext } from '../../contexts/ThemeContext';
import BookmarksPanel from './BookmarksPanel';
import HistoryPanel from './HistoryPanel';
import DownloadsPanel from './DownloadsPanel';
import SettingsPanel from './SettingsPanel';
import { Bookmark, Clock, Download, Settings, X } from 'lucide-react';

const Sidebar: React.FC = () => {
  const { sidebarContent, setSidebarContent, setShowSidebar } = useContext(BrowserContext);
  const { theme } = useContext(ThemeContext);

  return (
    <aside className={`w-80 flex flex-col border-r ${
      theme === 'dark' ? 'bg-gray-800 border-gray-700 text-white' : 'bg-white border-gray-200 text-gray-900'
    }`}>
      <div className={`flex items-center justify-between p-3 border-b ${
        theme === 'dark' ? 'border-gray-700' : 'border-gray-200'
      }`}>
        <h2 className="text-lg font-semibold">
          {sidebarContent === 'bookmarks' && 'Bookmarks'}
          {sidebarContent === 'history' && 'History'}
          {sidebarContent === 'downloads' && 'Downloads'}
          {sidebarContent === 'settings' && 'Settings'}
        </h2>
        <button 
          onClick={() => setShowSidebar(false)}
          className={`p-2 rounded-full ${
            theme === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-200'
          }`}
        >
          <X size={18} />
        </button>
      </div>
      
      <div className={`flex border-b ${
        theme === 'dark' ? 'border-gray-700' : 'border-gray-200'
      }`}>
        <button 
          className={`flex-1 py-2 text-center ${
            sidebarContent === 'bookmarks' 
              ? theme === 'dark' 
                ? 'bg-gray-700' 
                : 'bg-gray-100' 
              : ''
          }`}
          onClick={() => setSidebarContent('bookmarks')}
        >
          <Bookmark size={18} className="mx-auto" />
        </button>
        <button 
          className={`flex-1 py-2 text-center ${
            sidebarContent === 'history' 
              ? theme === 'dark' 
                ? 'bg-gray-700' 
                : 'bg-gray-100' 
              : ''
          }`}
          onClick={() => setSidebarContent('history')}
        >
          <Clock size={18} className="mx-auto" />
        </button>
        <button 
          className={`flex-1 py-2 text-center ${
            sidebarContent === 'downloads' 
              ? theme === 'dark' 
                ? 'bg-gray-700' 
                : 'bg-gray-100' 
              : ''
          }`}
          onClick={() => setSidebarContent('downloads')}
        >
          <Download size={18} className="mx-auto" />
        </button>
        <button 
          className={`flex-1 py-2 text-center ${
            sidebarContent === 'settings' 
              ? theme === 'dark' 
                ? 'bg-gray-700' 
                : 'bg-gray-100' 
              : ''
          }`}
          onClick={() => setSidebarContent('settings')}
        >
          <Settings size={18} className="mx-auto" />
        </button>
      </div>
      
      <div className="flex-1 overflow-y-auto">
        {sidebarContent === 'bookmarks' && <BookmarksPanel />}
        {sidebarContent === 'history' && <HistoryPanel />}
        {sidebarContent === 'downloads' && <DownloadsPanel />}
        {sidebarContent === 'settings' && <SettingsPanel />}
      </div>
    </aside>
  );
};

export default Sidebar;