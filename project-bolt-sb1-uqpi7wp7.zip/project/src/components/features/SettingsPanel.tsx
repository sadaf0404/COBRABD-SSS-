import React, { useContext, useState } from 'react';
import { ThemeContext } from '../../contexts/ThemeContext';
import { BrowserContext } from '../../contexts/BrowserContext';
import { Sun, Moon, Shield, Paintbrush } from 'lucide-react';

const ACCENT_COLORS = [
  { name: 'Blue', value: '#3B82F6' },
  { name: 'Purple', value: '#8B5CF6' },
  { name: 'Pink', value: '#EC4899' },
  { name: 'Orange', value: '#F97316' },
  { name: 'Green', value: '#10B981' },
  { name: 'Teal', value: '#14B8A6' },
];

const SettingsPanel: React.FC = () => {
  const { theme, toggleTheme, accentColor, setAccentColor } = useContext(ThemeContext);
  const { isPrivateMode, togglePrivateMode } = useContext(BrowserContext);

  return (
    <div className="p-4">
      <div className={`mb-6 p-4 rounded-lg ${
        theme === 'dark' ? 'bg-gray-700' : 'bg-gray-100'
      }`}>
        <h3 className="text-lg font-medium mb-3 flex items-center">
          <Paintbrush size={18} className="mr-2" />
          Appearance
        </h3>
        
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <span>Theme</span>
            <button
              onClick={toggleTheme}
              className={`flex items-center justify-center w-12 h-6 rounded-full ${
                theme === 'dark' ? 'bg-gray-600' : 'bg-gray-300'
              } relative transition-colors`}
            >
              <div className={`absolute w-5 h-5 rounded-full transform transition-transform ${
                theme === 'dark' ? 'translate-x-3 bg-gray-800' : '-translate-x-3 bg-white'
              }`}></div>
              {theme === 'dark' ? (
                <Moon size={12} className="absolute text-white -translate-x-3" />
              ) : (
                <Sun size={12} className="absolute text-yellow-500 translate-x-3" />
              )}
            </button>
          </div>
          <p className={`text-xs ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
            {theme === 'dark' ? 'Using dark theme' : 'Using light theme'}
          </p>
        </div>
        
        <div>
          <div className="mb-2">Accent Color</div>
          <div className="grid grid-cols-6 gap-2">
            {ACCENT_COLORS.map(color => (
              <button
                key={color.value}
                className={`w-full aspect-square rounded-full ${
                  accentColor === color.value ? 'ring-2 ring-offset-2 ring-offset-gray-50 ring-gray-400' : ''
                }`}
                style={{ backgroundColor: color.value }}
                onClick={() => setAccentColor(color.value)}
                aria-label={`Select ${color.name} accent color`}
              />
            ))}
          </div>
        </div>
      </div>
      
      <div className={`mb-6 p-4 rounded-lg ${
        theme === 'dark' ? 'bg-gray-700' : 'bg-gray-100'
      }`}>
        <h3 className="text-lg font-medium mb-3 flex items-center">
          <Shield size={18} className="mr-2" />
          Privacy & Security
        </h3>
        
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <span>Private Browsing</span>
            <button
              onClick={togglePrivateMode}
              className={`flex items-center justify-center w-12 h-6 rounded-full ${
                isPrivateMode ? 'bg-purple-600' : theme === 'dark' ? 'bg-gray-600' : 'bg-gray-300'
              } relative transition-colors`}
            >
              <div className={`absolute w-5 h-5 rounded-full bg-white transform transition-transform ${
                isPrivateMode ? 'translate-x-3' : '-translate-x-3'
              }`}></div>
            </button>
          </div>
          <p className={`text-xs ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
            {isPrivateMode ? 
              'History will not be saved in private mode' : 
              'Browsing history is being saved'
            }
          </p>
        </div>
      </div>
      
      <div className="text-center text-sm mt-8">
        <p className={theme === 'dark' ? 'text-gray-500' : 'text-gray-400'}>
          COBRABD(SSS) Browser
        </p>
        <p className={theme === 'dark' ? 'text-gray-600' : 'text-gray-400'}>
          Version 1.0.0
        </p>
      </div>
    </div>
  );
};

export default SettingsPanel;