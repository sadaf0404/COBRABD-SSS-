import React, { useContext } from 'react';
import { ThemeContext } from '../../contexts/ThemeContext';
import { Download, FileDown } from 'lucide-react';

const DownloadsPanel: React.FC = () => {
  const { theme } = useContext(ThemeContext);
  
  // In a real application, this would come from a context or state
  const downloads: any[] = [];

  return (
    <div className="p-3">
      <div className="flex flex-col items-center justify-center h-40 text-center">
        <FileDown size={32} className={`mb-2 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`} />
        <p className={theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}>
          No downloads yet
        </p>
        <p className={`text-sm mt-1 ${theme === 'dark' ? 'text-gray-500' : 'text-gray-400'}`}>
          Downloads will appear here when you download files
        </p>
      </div>
    </div>
  );
};

export default DownloadsPanel;