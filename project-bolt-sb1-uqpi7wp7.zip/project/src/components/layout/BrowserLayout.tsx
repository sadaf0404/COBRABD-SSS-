import React, { useContext } from 'react';
import { BrowserContext } from '../../contexts/BrowserContext';
import { ThemeContext } from '../../contexts/ThemeContext';
import TabBar from '../browser/TabBar';
import NavigationBar from '../browser/NavigationBar';
import BrowserContent from '../browser/BrowserContent';
import Sidebar from '../features/Sidebar';
import { Settings, Menu } from 'lucide-react';

const BrowserLayout: React.FC = () => {
  const { showSidebar, setShowSidebar } = useContext(BrowserContext);
  const { theme } = useContext(ThemeContext);

  return (
    <div className={`h-screen flex flex-col ${theme === 'dark' ? 'bg-gray-900 text-white' : 'bg-white text-gray-900'}`}>
      <header className={`border-b ${theme === 'dark' ? 'border-gray-700' : 'border-gray-200'}`}>
        <TabBar />
        <NavigationBar />
      </header>
      
      <div className="flex-1 flex overflow-hidden">
        {showSidebar && <Sidebar />}
        <BrowserContent />
      </div>
      
      <button 
        onClick={() => setShowSidebar(!showSidebar)}
        className={`absolute bottom-4 left-4 p-2 rounded-full ${
          theme === 'dark' ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-100 hover:bg-gray-200'
        } transition-colors duration-200`}
      >
        <Menu size={20} />
      </button>
    </div>
  );
};

export default BrowserLayout;