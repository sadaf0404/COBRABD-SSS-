export interface Tab {
  id: string;
  url: string;
  title: string;
  favicon: string;
  history: string[]; // Array of URLs for navigation history
  historyIndex: number; // Current position in history
  isLoading: boolean;
}

export interface Bookmark {
  id: string;
  url: string;
  title: string;
  createdAt: string;
}

export interface HistoryItem {
  id: string;
  url: string;
  title: string;
  visits: number;
  firstVisit: string;
  lastVisit: string;
}

export interface Download {
  id: string;
  filename: string;
  url: string;
  state: 'in_progress' | 'complete' | 'failed';
  progress: number;
  totalBytes?: number;
  receivedBytes?: number;
  startTime: string;
  endTime?: string;
}

export interface SearchEngine {
  name: string;
  searchUrl: string;
  iconUrl: string;
}