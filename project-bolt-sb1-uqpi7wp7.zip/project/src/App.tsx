import React, { useState, useEffect } from 'react';
import BrowserLayout from './components/layout/BrowserLayout';
import BrowserProvider from './contexts/BrowserContext';
import ThemeProvider from './contexts/ThemeContext';

function App() {
  return (
    <ThemeProvider>
      <BrowserProvider>
        <BrowserLayout />
      </BrowserProvider>
    </ThemeProvider>
  );
}

export default App;